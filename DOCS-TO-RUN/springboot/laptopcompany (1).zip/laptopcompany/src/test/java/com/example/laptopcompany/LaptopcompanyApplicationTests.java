package com.example.laptopcompany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaptopcompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
