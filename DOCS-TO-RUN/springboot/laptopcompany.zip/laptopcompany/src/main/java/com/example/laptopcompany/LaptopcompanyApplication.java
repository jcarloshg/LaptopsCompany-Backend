package com.example.laptopcompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaptopcompanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaptopcompanyApplication.class, args);
	}

}
